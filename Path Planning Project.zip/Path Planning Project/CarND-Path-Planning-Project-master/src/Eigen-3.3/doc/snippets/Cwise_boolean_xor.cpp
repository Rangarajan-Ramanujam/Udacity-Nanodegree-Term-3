Array3d v(-1,2,1), w(-3,2,3);
cout << ((v<w) ^ (v<0)) << endl;
